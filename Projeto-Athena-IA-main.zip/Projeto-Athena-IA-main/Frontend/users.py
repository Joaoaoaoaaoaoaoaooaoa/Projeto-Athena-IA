from fastapi import APIRouter, Depends
from backend.api.deps import get_current_user
from backend.models.user import User
from backend.schemas.user import UserResponse

router = APIRouter(prefix="/users", tags=["Users"])

@router.get("/me", response_model=UserResponse)
def me(user: User = Depends(get_current_user)):
    return user
